module Exemplo1_Heran�a {
}