module ExcemploExcecao {
}