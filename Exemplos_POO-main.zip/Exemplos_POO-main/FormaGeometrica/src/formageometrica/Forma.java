/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package formageometrica;

/**
 *
 * @author Hanne
 */
abstract class Forma {

public abstract void desenhar(); // m�todo que n�o possui codigo fonte
public abstract void aumentar(int t);
}

