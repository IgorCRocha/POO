module Revista_cientifica {
	requires java.desktop;
	
}