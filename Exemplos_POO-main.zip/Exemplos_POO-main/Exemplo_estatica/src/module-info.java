module Exemplo_estatica {
}