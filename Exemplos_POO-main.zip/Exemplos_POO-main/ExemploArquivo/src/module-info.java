module ExemploArquivo {
	requires java.sql;
}