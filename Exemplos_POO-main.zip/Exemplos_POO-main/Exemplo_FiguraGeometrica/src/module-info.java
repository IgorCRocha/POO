module Exemplo_FiguraGeometrica {
}