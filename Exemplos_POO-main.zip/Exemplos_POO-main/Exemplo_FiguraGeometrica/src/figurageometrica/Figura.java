package figurageometrica;

public abstract class Figura {

}
