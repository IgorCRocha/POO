/**
 * 
 */
/**
 * @author Michelle Note
 *
 */
module ExemploHeranca_Conta {
}