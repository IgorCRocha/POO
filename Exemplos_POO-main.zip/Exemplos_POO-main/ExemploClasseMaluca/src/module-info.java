module ExemploClasseMaluca {
}