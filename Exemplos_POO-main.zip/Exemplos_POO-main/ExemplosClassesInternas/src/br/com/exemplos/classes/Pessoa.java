package br.com.exemplos.classes;

abstract class Pessoa {
	abstract void comer();
}
