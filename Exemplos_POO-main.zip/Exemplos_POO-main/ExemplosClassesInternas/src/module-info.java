module ExemplosClassesInternas {
}