module Exemplo_Circulo {
}