/**
 * 
 */
/**
 * @author Michelle Note
 *
 */
module ExemploEstoque {
}